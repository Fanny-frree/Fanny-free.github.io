package test;

import java.util.Map;
import java.util.Map.Entry;

//ͳ���ı��еĴ�Ƶ��
public class CountOccurrenceOfWords {
	
			public String[]  query(Map<String, Integer> Map,String s) {
				String[] word= s.split(",");//ʹ�ö��Ÿ�������
		        int i;
		        for(i=0; i<word.length; i++) {
		        	for(Entry<String,Integer> entry : Map.entrySet()) { 
		        		if(word[i].equals(entry.getKey()))
		        		{
		        			System.out.println(entry.getKey() + ":\t " + entry.getValue()); 
		        			break;
		        		}
		            } 
		        }
				return word;
		    }
	}

